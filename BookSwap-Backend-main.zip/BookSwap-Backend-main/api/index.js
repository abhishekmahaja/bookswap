import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";
import serverless from "serverless-http";

import connectToDatabase from "../db/db.js";
import authRoutes from "../routes/authRoutes.js";
import bookRoutes from "../routes/bookRoutes.js";
import reviewRoutes from "../routes/reviewRoutes.js";

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/v1/auth", authRoutes);
app.use("/api/v1/books", bookRoutes);
app.use("/api/v1/review", reviewRoutes);

const isLocal = process.env.IS_LOCAL === "true";

// Local server (for development)
if (isLocal) {
  const startServer = async () => {
    try {
      await connectToDatabase();
      const PORT = process.env.PORT || 6300;
      app.listen(PORT, () => {
        console.log(`Local server running at http://localhost:${PORT}`);
      });
    } catch (error) {
      console.error("Failed to start local server:", error.message);
    }
  };

  startServer();
}

// Serverless handler (for Vercel)
let handlerCached = null;

export const handler = async (event, context) => {
  if (!handlerCached) {
    try {
      await connectToDatabase(); 
      handlerCached = serverless(app);
    } catch (err) {
      console.error("Serverless DB connection error:", err.message);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Failed to connect to DB" }),
      };
    }
  }

  return handlerCached(event, context);
};
